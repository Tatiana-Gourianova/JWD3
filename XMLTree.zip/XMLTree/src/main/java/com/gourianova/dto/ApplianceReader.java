package com.gourianova.dto;

public class ApplianceReader {

}
