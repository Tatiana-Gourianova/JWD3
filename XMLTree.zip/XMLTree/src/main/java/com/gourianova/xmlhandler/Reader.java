package com.gourianova.xmlhandler;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import com.gourianova.dto.ApplianceReader;
import com.gourianova.entity.Node;

public class Reader {
    private static File Path;
    private static String path = "E:\\new_doc\\JWDTask3\\XMLTree\\src\\main\\resources\\";
    private static String FileName;
    //public String FileName="";//="breakfast.xml";

    public Reader(String File){
        this.FileName=File;
    }
    private List<String> AllLines;
    public List<String> getAllLines () {
        return AllLines;
    }
  //  public static String getFileName () {
    //    return FileName;
   // ..}
    public void setAllLines () {
        this.AllLines = takeAll();
    }
    public List<String> takeAll () {

        List<String> allLines = null;

///    Parser parser = new Parser();


            try {

                allLines = Files.readAllLines(Paths.get(path, FileName));
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
            return allLines;
        }

/*
    public void readFile(String path) {
    //    path="E:\\new_doc\\JWDTask3\\XMLTree\\src\\main\\resources\\breakfast.xml";

        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(path))) {
            Updater xmlUpdater = new Updater();
            xmlUpdater.readFile(path);
            readFile(bufferedReader);
        } catch (FileNotFoundException e) {
            System.out.print("Under construction, try to write the path at 15 line of Reader.java");
        } catch (IOException e) {
            System.out.print("Under construction");
        }
    }

    public void readFile(BufferedReader bufferedReader) {
        String xmlInform = "";
        try {
            while ((xmlInform = bufferedReader.readLine()) != null) {
                xmlInform = xmlInform.trim();
                parser.parseOpenTag(xmlInform);
                parser.parseDataTag(xmlInform);
                parser.parseCloseTag(xmlInform);
            }
        } catch (IOException e) {
            System.out.print("Under construction");
        }

    }

*/
    }

