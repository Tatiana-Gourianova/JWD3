package com.gourianova.entity;

public enum Tag {
    Open, Data, Close
}